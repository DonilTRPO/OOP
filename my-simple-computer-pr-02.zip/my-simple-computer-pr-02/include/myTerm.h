#pragma once
#include <stdio.h>

enum colors
{
  BLACK,
  RED,
  GREEN,
  YELLOW,
  BLUE,
  MAGENTA,
  CYAN,
  WHITE,
  DEFAULT
};

typedef struct
{
  int address;
  int value;
  int input;
} InOutHistory;

int myTerm (void);
int mt_gotoXY (int x, int y);
int mt_getscreensize (int *rows, int *cols);
int mt_setfgcolor (enum colors color);
int mt_setbgcolor (enum colors color);
int mt_setdefaultcolor (void);
int mt_setcursorvisible (int value);
int mt_delline (void);
int mt_clrscr (void);
void printTerm (int address, int input);
void printCommand (void);
