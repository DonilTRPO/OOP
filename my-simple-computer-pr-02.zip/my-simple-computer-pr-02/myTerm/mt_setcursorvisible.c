#include <myTerm.h>
#include <stdio.h>
#include <unistd.h>

int
mt_setcursorvisible (int visible)
{
  const char *command = visible ? "\033[?25h" : "\033[?25l";
  if (write (STDOUT_FILENO, command, visible ? 6 : 6) == -1)
    {
      return -1;
    }
  return 0;
}
