#include <myTerm.h>
#include <stdio.h>
#include <unistd.h>

int
mt_setdefaultcolor (void)
{
  const char *default_colors = "\033[0m";
  if (write (STDOUT_FILENO, default_colors, 4) == -1)
    {
      return -1;
    }
  return 0;
}
