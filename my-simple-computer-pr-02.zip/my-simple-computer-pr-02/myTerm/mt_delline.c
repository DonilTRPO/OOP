#include <myTerm.h>
#include <stdio.h>
#include <unistd.h>

int
mt_delline (void)
{
  const char *clr_line = "\033[2K";
  if (write (STDOUT_FILENO, clr_line, 4) == -1)
    {
      return -1;
    }
  return 0;
}
