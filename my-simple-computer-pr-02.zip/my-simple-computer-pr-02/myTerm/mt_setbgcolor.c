#include <myTerm.h>
#include <stdio.h>
#include <unistd.h>

int
mt_setbgcolor (enum colors color)
{
  char command[13];
  int cmd_length
      = snprintf (command, sizeof (command), "\033[48;5;%dm", color);
  if (write (STDOUT_FILENO, command, cmd_length) == -1)
    {
      return -1;
    }
  return 0;
}
