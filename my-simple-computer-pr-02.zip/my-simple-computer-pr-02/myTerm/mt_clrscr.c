#include <myTerm.h>
#include <stdio.h>
#include <unistd.h>

int
mt_clrscr (void)
{
  const char *clrscr = "\033[2J\033[1;1H";
  if (write (STDOUT_FILENO, clrscr, 7) == -1)
    {
      return -1;
    }
  return 0;
}
