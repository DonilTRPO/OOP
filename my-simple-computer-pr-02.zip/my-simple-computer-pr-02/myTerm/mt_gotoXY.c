#include <myTerm.h>
#include <stdio.h>
#include <unistd.h>

int
mt_gotoXY (int x, int y)
{
  char command[20];
  int cmd_length = snprintf (command, sizeof (command), "\033[%d;%dH", x, y);
  if (write (STDOUT_FILENO, command, cmd_length) == -1)
    {
      return -1;
    }
  return 0;
}
