#include "sc_variables.h"
int
sc_icounterInit (void)
{
  icounter = 0;
  return 0;
}