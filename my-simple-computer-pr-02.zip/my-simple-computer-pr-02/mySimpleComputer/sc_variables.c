#include "sc_variables.h"

int RAM[SIZERAM];
short reg_flag;
int accumulator;
int icounter;