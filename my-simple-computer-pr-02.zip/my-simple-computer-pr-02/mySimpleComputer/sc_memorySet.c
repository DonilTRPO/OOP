#include "sc_variables.h"
int
sc_memorySet (int address, int value)
{
  if ((address >= 0 && address < 128) && (value < 0xFFFF))
    {
      RAM[address] = value;
      return 0;
    }
  return -1;
}