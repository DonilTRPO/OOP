#include "sc_variables.h"
int
sc_icounterGet (int *value)
{
  if (*value >= 0xFFFF)
    {
      return -1;
    }
  *value = icounter;
  return 0;
}