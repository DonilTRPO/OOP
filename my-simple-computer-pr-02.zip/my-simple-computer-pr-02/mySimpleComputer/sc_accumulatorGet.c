#include "sc_variables.h"
int
sc_accumulatorGet (int *value)
{
  if (*value >= 0xFFFF)
    {
      return -1;
    }
  *value = accumulator;
  return 0;
}