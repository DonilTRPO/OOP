#include "sc_variables.h"
int
sc_memoryGet (int address, int *value)
{
  if (address >= 0 && address < 128)
    {
      *value = RAM[address];
      return 0;
    }
  return -1;
}