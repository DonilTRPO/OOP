#include "sc_variables.h"
int
sc_accumulatorSet (int value)
{
  if (value < 0xFFFF)
    {
      accumulator = value;
      return 0;
    }
  return -1;
}