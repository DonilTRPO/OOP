#pragma once
#include <stdio.h>
#define OFF 0
#define ON 1
#define SIZERAM 128
#define PO 0b00000001
#define ED 0b00000010
#define EM 0b00000100
#define EC 0b00001000
#define II 0b00010000
extern int accumulator;
extern int RAM[SIZERAM];
extern short reg_flag;
extern int icounter;