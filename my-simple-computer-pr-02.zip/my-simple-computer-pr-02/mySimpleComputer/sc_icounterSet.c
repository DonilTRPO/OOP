#include "sc_variables.h"
int
sc_icounterSet (int value)
{
  if (value < 0xFFFF)
    {
      icounter = value;
      return 0;
    }
  return -1;
}
