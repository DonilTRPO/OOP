#include "sc_variables.h"
int
sc_regGet (int register1, int *value)
{
  if (!value)
    {
      return -1;
    }

  if (register1 == PO)
    {
      *value = reg_flag & 0x1;
    }
  else if (register1 == ED)
    {
      *value = (reg_flag >> 1) & 0x1;
    }
  else if (register1 == EM)
    {
      *value = (reg_flag >> 2) & 0x1;
    }
  else if (register1 == EC)
    {
      *value = (reg_flag >> 3) & 0x1;
    }
  else if (register1 == II)
    {
      *value = (reg_flag >> 4) & 0x1;
    }
  else
    {
      return -1;
    }

  return 0;
}