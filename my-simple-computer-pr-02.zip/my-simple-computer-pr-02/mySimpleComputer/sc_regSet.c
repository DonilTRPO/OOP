#include "sc_variables.h"
int
sc_regSet (int register1, int value)
{
  if (register1 == PO || register1 == ED || register1 == EM || register1 == EC
      || register1 == II)
    {
      if (value == 0)
        {
          reg_flag = reg_flag & (~(register1));
        }
      if (value == 1)
        {
          reg_flag = reg_flag | register1;
        }
      else
        {
          return -1;
        }
    }
  else
    {
      return -1;
    }

  return 0;
}