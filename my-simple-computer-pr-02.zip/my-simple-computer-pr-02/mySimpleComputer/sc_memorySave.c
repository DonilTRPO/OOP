#include "sc_variables.h"
int
sc_memorySave (char *filename)
{
  FILE *file;
  file = fopen (filename, "wb");
  if (file == NULL)
    {
      printf ("Ошибка открытия файла");
      return -1;
    }
  fwrite (RAM, sizeof (int), 128, file);
  fclose (file);
  return 0;
}