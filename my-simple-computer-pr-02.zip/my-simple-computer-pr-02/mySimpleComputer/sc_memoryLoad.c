#include "sc_variables.h"
int
sc_memoryLoad (char *filename)
{
  FILE *file;
  int i;
  file = fopen (filename, "rb");
  if (file == NULL)
    {
      printf ("Ошибка открытия файла");
      return -1;
    }

  for (i = 0; i < 128; i++)
    {

      fscanf (file, "%d", &RAM[i]);
    }
  fclose (file);
  return 0;
}