#include "sc_variables.h"
int
sc_regInit (void)
{
  reg_flag = 0x10;
  return 0;
}
