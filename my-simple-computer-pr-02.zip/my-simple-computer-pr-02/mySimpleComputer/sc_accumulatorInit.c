#include "sc_variables.h"
int
sc_accumulatorInit (void)
{
  accumulator = 0;
  return 0;
}
