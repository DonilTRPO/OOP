Пеалкиви Даниил Яковлевич, ИС-242
A software model of the simplest
computer, Simple Computer, and a set of utilities for creating software for it.
