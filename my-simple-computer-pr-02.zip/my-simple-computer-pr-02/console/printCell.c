#include <mySimpleComputer.h>
#include <myTerm.h>
#include <stdio.h>

void
printCell (int address, enum colors fg, enum colors bg)
{
  int value;
  if (sc_memoryGet (address, &value) != -1)
    {
      int sign, command, operand;

      sc_memoryGet (address, &value);
      sc_commandDecode (value, &sign, &command, &operand);

      mt_setfgcolor (bg);
      mt_setbgcolor (fg);

      printf (" %c%02X%02X ", sign ? '-' : '+', command, operand);

      mt_setdefaultcolor ();
    }
  else
    {
      printf ("Invalid memory address\n");
    }
}
