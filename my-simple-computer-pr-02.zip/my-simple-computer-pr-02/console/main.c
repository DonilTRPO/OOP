#include <mySimpleComputer.h>
#include <myTerm.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int
main ()
{

  sc_memoryInit ();
  sc_regInit ();
  sc_icounterInit ();
  srand (time (NULL));

  mt_clrscr ();

  printAccumulator ();

  mt_gotoXY (1, 1);
  for (int address = 0; address < 10; address++)
    {
      printCell (address, WHITE, BLACK);
    }
  printf ("\n");
  sc_memorySet (1, 12);
  for (int address = 0; address < 10; address++)
    {
      printCell (address, WHITE, BLACK);
    }
  printf ("\n");
  for (int address = 0; address < 10; address++)
    {
      printCell (address, WHITE, BLACK);
    }
  printf ("\n");
  for (int address = 0; address < 10; address++)
    {
      printCell (address, WHITE, BLACK);
    }
  printf ("\n");
  for (int address = 0; address < 10; address++)
    {
      printCell (address, WHITE, BLACK);
    }
  printf ("\n");
  sc_memorySet (4, 15);
  for (int address = 0; address < 10; address++)
    {
      printCell (address, WHITE, BLACK);
    }
  printf ("\n");
  for (int address = 0; address < 10; address++)
    {
      printCell (address, WHITE, BLACK);
    }
  printf ("\n");
  for (int address = 0; address < 10; address++)
    {
      printCell (address, WHITE, BLACK);
    }
  printf ("\n");

  for (int address = 0; address < 10; address++)
    {
      printCell (address, WHITE, BLACK);
    }
  printf ("\n");
  for (int address = 0; address < 8; address++)
    {
      printCell (address, WHITE, BLACK);
    }
  printf ("\n");

  printCounters ();

  sc_regSet (4, 1);
  printFlags ();

  printTerm (5, 0);

  mt_gotoXY (20, 1);
}
