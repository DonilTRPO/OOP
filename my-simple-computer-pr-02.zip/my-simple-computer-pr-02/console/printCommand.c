#include <mySimpleComputer.h>
#include <myTerm.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

void
printCommand ()
{
  int value = 0, sign = 0, command = 0, operand = 0;
  char tmp[256];

  sc_icounterGet (&value);
  sc_commandDecode (value, &sign, &command, &operand);

  if (command >= 0 && command <= 76)
    {
      snprintf (tmp, sizeof (tmp), "+ %.2x : %.2x", command, operand);
    }
  else
    {
      snprintf (tmp, sizeof (tmp), "! %.2x : %.2x", command, operand);
    }

  write (STDOUT_FILENO, tmp, strlen (tmp));
}
