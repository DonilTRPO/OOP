#include <mySimpleComputer.h>
#include <myTerm.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

void
printFlags (void)
{
  char str[5] = "POMTE";
  int flag = 1;
  char output[256] = { 0 };
  char *ptr = output;

  for (int i = 0; i < 5; i++)
    {
      int value = 1;
      sc_regGet (flag, &value);
      if (value == 0)
        {
          ptr += sprintf (ptr, "_ ");
        }
      else
        {
          ptr += sprintf (ptr, "%c ", str[i]);
        }
      flag *= 2;
    }

  mt_gotoXY (1, 110);
  write (STDOUT_FILENO, output, strlen (output));
}
