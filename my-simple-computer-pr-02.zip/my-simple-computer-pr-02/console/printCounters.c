#include <mySimpleComputer.h>
#include <myTerm.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

void
printCounters (void)
{
  int value = 0;
  int sign;
  int command;
  int operand;
  sc_icounterGet (&value);
  sc_commandDecode (value, &sign, &command, &operand);

  char buf[100] = { 0 };
  int len;

  if (sign == 0)
    {
      len = sprintf (buf, "T:        IC: +%.2x%.2x", command, operand);
    }
  else
    {
      len = sprintf (buf, "T:        IC: -%.2x%.2x", command, operand);
    }

  mt_gotoXY (3, 80);
  write (STDOUT_FILENO, buf, len);
}
