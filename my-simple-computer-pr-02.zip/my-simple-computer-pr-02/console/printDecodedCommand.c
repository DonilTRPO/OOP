#include <mySimpleComputer.h>
#include <myTerm.h>
#include <stdio.h>
#include <unistd.h>

void
printDecodedCommand (int value)
{
  char buffer[256];
  int step = 0;
  int testValue = 1;
  while (testValue <= value)
    {
      testValue <<= 1;
      step++;
    }
  step--;

  int length
      = sprintf (buffer, "dec: %d  |  oct: %o  |  hex: %X      bin: ", value,
                 value, value);
  for (int i = step; i >= 0; i--)
    {
      length += sprintf (buffer + length, "%d", (value >> i) & 1);
    }
  length += sprintf (buffer + length, "\n");

  mt_gotoXY (15, 1);
  write (STDOUT_FILENO, buffer, length);
}
