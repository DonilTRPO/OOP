#include <mySimpleComputer.h>
#include <myTerm.h>
#include <stdio.h>
#include <unistd.h>

void
printAccumulator (void)
{
  int value = 0, sign, command, operand;
  sc_accumulatorGet (&value);
  sc_commandDecode (value, &sign, &command, &operand);

  char buffer[256];
  int length;

  if (sign == 0)
    {
      length = snprintf (buffer, sizeof (buffer), "sc: +%02x%02x hex: %04X\n",
                         command, operand, value);
    }
  else
    {
      length = snprintf (buffer, sizeof (buffer), "sc: -%02x%02x hex: %04X\n",
                         command, operand, value);
    }

  mt_gotoXY (1, 80);

  write (STDOUT_FILENO, buffer, length);
}
